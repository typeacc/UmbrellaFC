# Umbrella Template

Client-side football graphic generator for GitHub Pages.

Files can be placed directly in the repository root. No `assets` folder, Node.js, npm, backend, database, API, or external service is required.

The exported graphic is 1080 × 1920 PNG and includes separate scorer columns for both teams.
