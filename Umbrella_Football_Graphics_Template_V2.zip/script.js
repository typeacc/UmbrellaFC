(() => {
  const $ = id => document.getElementById(id);
  const canvas = $('preview');
  const ctx = canvas.getContext('2d');
  const W = 1080, H = 1920;
  let photo = null, photoURL = null;
  const logo = new Image();
  logo.src = 'umbrella-logo.png';
  const state = { zoom:100, x:50, y:50 };
  const defaults = [['Placeholder1',2],['Placeholder2',1],['Placeholder3',1]];

  const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
  const text=v=>String(v??'').trim();

  function addScorer(containerId,name='',goals=1){
    const row=document.createElement('div'); row.className='scorer-row';
    row.innerHTML='<input class="scorer-name" type="text" maxlength="22" placeholder="Player name"><input class="scorer-goals" type="number" min="1" max="99" value="1"><button class="remove" type="button" aria-label="Remove scorer">×</button>';
    row.querySelector('.scorer-name').value=name;
    row.querySelector('.scorer-goals').value=goals;
    row.querySelector('.remove').onclick=()=>{row.remove();draw()};
    row.querySelectorAll('input').forEach(el=>el.addEventListener('input',draw));
    $(containerId).appendChild(row);
  }
  function getScorers(id){
    return [...$(id).querySelectorAll('.scorer-row')].map(r=>({name:text(r.querySelector('.scorer-name').value),goals:clamp(parseInt(r.querySelector('.scorer-goals').value||1,10),1,99)})).filter(s=>s.name);
  }

  // Matches the supplied reference silhouette: large portrait content area with an angled upper-right shoulder.
  function templatePath(){
    const p=new Path2D();
    p.moveTo(58,250); p.lineTo(680,250); p.lineTo(805,170); p.lineTo(1022,170);
    p.lineTo(1022,1848); p.lineTo(58,1848); p.closePath(); return p;
  }
  function makeMetal(){
    const c=document.createElement('canvas');c.width=180;c.height=180;const x=c.getContext('2d');
    x.fillStyle='#7f878a';x.fillRect(0,0,180,180);
    for(let i=0;i<180;i+=3){x.fillStyle=`rgba(255,255,255,${.02+Math.random()*.03})`;x.fillRect(0,i,180,1)}
    for(let i=0;i<180;i+=18){x.fillStyle='rgba(0,0,0,.025)';x.fillRect(0,i,180,2)}
    return ctx.createPattern(c,'repeat');
  }
  function makeDiamond(){
    const c=document.createElement('canvas');c.width=72;c.height=72;const x=c.getContext('2d');
    x.fillStyle='#b8bec1';x.fillRect(0,0,72,72);
    for(let y=-72;y<144;y+=24)for(let xx=-72;xx<144;xx+=24){
      x.beginPath();x.moveTo(xx+12,y);x.lineTo(xx+24,y+12);x.lineTo(xx+12,y+24);x.lineTo(xx,y+12);x.closePath();
      x.fillStyle='rgba(255,255,255,.12)';x.fill();x.strokeStyle='rgba(45,48,49,.52)';x.lineWidth=2;x.stroke();
    }
    return ctx.createPattern(c,'repeat');
  }
  const metal=makeMetal(), diamond=makeDiamond();

  function drawPhoto(){
    if(!photo)return;
    const p=templatePath();ctx.save();ctx.clip(p);
    const iw=photo.naturalWidth||photo.width, ih=photo.naturalHeight||photo.height;
    const boxW=964,boxH=1678;
    const scale=Math.max(boxW/iw,boxH/ih)*(state.zoom/100);
    const dw=iw*scale,dh=ih*scale;
    const x=58-(dw-boxW)*(state.x/100), y=170-(dh-boxH)*(state.y/100);
    ctx.drawImage(photo,x,y,dw,dh);ctx.restore();
  }
  function rounded(x,y,w,h,r){const p=new Path2D();p.moveTo(x+r,y);p.lineTo(x+w-r,y);p.quadraticCurveTo(x+w,y,x+w,y+r);p.lineTo(x+w,y+h-r);p.quadraticCurveTo(x+w,y+h,x+w-r,y+h);p.lineTo(x+r,y+h);p.quadraticCurveTo(x,y+h,x,y+h-r);p.lineTo(x,y+r);p.quadraticCurveTo(x,y,x+r,y);p.closePath();return p}
  function fit(s,max,min,width,weight='800'){let n=max;ctx.font=`${weight} ${n}px Arial`;while(n>min&&ctx.measureText(s).width>width){n--;ctx.font=`${weight} ${n}px Arial`}return n}

  function drawInfo(){
    const panel=rounded(90,1200,900,550,24);
    ctx.save();ctx.fillStyle='rgba(5,5,5,.70)';ctx.fill(panel);ctx.strokeStyle='rgba(235,238,239,.78)';ctx.lineWidth=3;ctx.stroke(panel);
    ctx.strokeStyle='#ff0000';ctx.lineWidth=6;ctx.beginPath();ctx.moveTo(118,1200);ctx.lineTo(370,1200);ctx.stroke();ctx.restore();

    const t1=text($('team1').value)||'TEAM 1',t2=text($('team2').value)||'TEAM 2';
    const s1=String(clamp(parseInt($('score1').value||0,10),0,99)),s2=String(clamp(parseInt($('score2').value||0,10),0,99));
    ctx.textBaseline='middle';ctx.textAlign='center';ctx.fillStyle='#f5f5f5';
    let f=fit(t1,42,22,280,'800');ctx.font=`800 ${f}px Arial`;ctx.fillText(t1,310,1275);
    f=fit(t2,42,22,280,'800');ctx.font=`800 ${f}px Arial`;ctx.fillText(t2,770,1275);
    ctx.fillStyle='#fff';ctx.font='800 64px Arial';ctx.fillText(`${s1} - ${s2}`,540,1275);
    ctx.fillStyle='#ff0000';ctx.fillRect(500,1332,80,4);

    drawScorerColumn(getScorers('scorers1'),130,1378,330,'left');
    drawScorerColumn(getScorers('scorers2'),950,1378,330,'right');
  }
  function drawScorerColumn(list,x,y,width,align){
    ctx.textAlign=align==='right'?'right':'left';ctx.fillStyle='#ff0000';ctx.font='800 17px Arial';ctx.fillText('GOALS',x,y);
    const yy=y+45;const rowH=list.length>5?45:52;
    if(!list.length){ctx.fillStyle='#aeb3b5';ctx.font='600 17px Arial';ctx.fillText('—',x,yy);return}
    list.slice(0,7).forEach((s,i)=>{
      const cy=yy+i*rowH;ctx.fillStyle='#f0f1f2';const fs=fit(s.name,25,14,width-70,'700');ctx.font=`700 ${fs}px Arial`;ctx.fillText(s.name,x,cy);
      ctx.fillStyle='#fff';ctx.font=`800 ${Math.max(17,fs)}px Arial`;ctx.textAlign=align==='right'?'left':'right';ctx.fillText(`×${s.goals}`,align==='right'?x-width:x+width,cy);ctx.textAlign=align==='right'?'right':'left';
      ctx.fillStyle='rgba(255,255,255,.12)';ctx.fillRect(align==='right'?x-width:x,cy+20,width,1);
    });
    if(list.length>7){ctx.fillStyle='#888';ctx.font='600 12px Arial';ctx.fillText(`+${list.length-7} more`,x,yy+7*rowH)}
  }

  function draw(){
    ctx.clearRect(0,0,W,H);
    ctx.fillStyle=metal;ctx.fillRect(0,0,W,H);
    const topSheen=ctx.createLinearGradient(0,0,0,H);topSheen.addColorStop(0,'rgba(255,255,255,.22)');topSheen.addColorStop(.25,'rgba(255,255,255,.04)');topSheen.addColorStop(1,'rgba(0,0,0,.13)');ctx.fillStyle=topSheen;ctx.fillRect(0,0,W,H);
    const p=templatePath();
    ctx.save();ctx.fillStyle=diamond;ctx.fill(p);ctx.restore();
    drawPhoto();
    ctx.save();ctx.strokeStyle='#101010';ctx.lineWidth=18;ctx.stroke(p);ctx.strokeStyle='#ff0000';ctx.lineWidth=5;ctx.stroke(p);ctx.restore();

    if(logo.complete)ctx.drawImage(logo,55,45,420,116);
    drawInfo();
  }

  function updateSliders(){state.zoom=+$('zoom').value;state.x=+$('posX').value;state.y=+$('posY').value;$('zoomValue').textContent=state.zoom+'%';$('xValue').textContent=state.x+'%';$('yValue').textContent=state.y+'%'}
  function update(){updateSliders();draw()}

  function loadFile(file){
    if(!file)return;if(!/^image\/(jpeg|png|webp)$/.test(file.type)){alert('Please choose a JPG, PNG, or WEBP image.');return}
    if(photoURL)URL.revokeObjectURL(photoURL);photoURL=URL.createObjectURL(file);photo=new Image();
    photo.onload=()=>{$('fileName').textContent=file.name;state.zoom=100;state.x=50;state.y=50;$('zoom').value=100;$('posX').value=50;$('posY').value=50;update()};photo.src=photoURL;
  }

  $('chooseImage').onclick=e=>{e.stopPropagation();$('imageInput').click()};
  $('dropzone').onclick=e=>{if(e.target!==$('chooseImage'))$('imageInput').click()};
  $('dropzone').onkeydown=e=>{if(e.key==='Enter'||e.key===' ')$('imageInput').click()};
  $('imageInput').onchange=e=>loadFile(e.target.files[0]);
  ['dragenter','dragover'].forEach(ev=>$('dropzone').addEventListener(ev,e=>{e.preventDefault();$('dropzone').classList.add('drag')}));
  ['dragleave','drop'].forEach(ev=>$('dropzone').addEventListener(ev,e=>{e.preventDefault();$('dropzone').classList.remove('drag')}));
  $('dropzone').ondrop=e=>loadFile(e.dataTransfer.files[0]);

  ['team1','team2','score1','score2'].forEach(id=>$(id).addEventListener('input',draw));
  ['zoom','posX','posY'].forEach(id=>$(id).addEventListener('input',update));
  $('addScorer1').onclick=()=>addScorer('scorers1');
  $('addScorer2').onclick=()=>addScorer('scorers2');
  $('resetPosition').onclick=()=>{$('zoom').value=100;$('posX').value=50;$('posY').value=50;update()};
  $('resetAll').onclick=()=>{
    $('team1').value='TEAM 1';$('team2').value='TEAM 2';$('score1').value=4;$('score2').value=2;
    $('scorers1').innerHTML='';$('scorers2').innerHTML='';defaults.forEach(s=>{addScorer('scorers1',s[0],s[1]);addScorer('scorers2',s[0],s[1])});
    $('zoom').value=100;$('posX').value=50;$('posY').value=50;if(photoURL)URL.revokeObjectURL(photoURL);photo=null;photoURL=null;$('imageInput').value='';$('fileName').textContent='No image selected';update();
  };
  $('download').onclick=()=>{draw();canvas.toBlob(blob=>{if(!blob)return;const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='Umbrella-Template.png';document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove()},500)},'image/png')};

  defaults.forEach(s=>{addScorer('scorers1',s[0],s[1]);addScorer('scorers2',s[0],s[1])});
  logo.onload=draw;update();
})();
